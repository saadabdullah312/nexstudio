import { Outlet } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import Navbar from './Navbar';

function App() {
  const { isDarkMode } = useTheme();

  return (
    <div
      className={`${isDarkMode ? 'bg-slate-900 text-white' : 'bg-slate-50 text-gray-900'} min-h-screen transition-colors duration-300`}
    >
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
}
export default App;
