import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import {
  addToCart,
  clearCart,
  decreaseQuantity,
  removeFromCart,
} from "../redux/cartSlice";

function Cart() {
  const { items } = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  const totalPrice = items.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );

  if (items.length === 0) {
    return (
      <div className="text-center py-20">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">
          Your cart is empty
        </h2>
        <Link to="/products" className="text-blue-600 hover:underline">
          Go shopping!
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-extrabold text-gray-900">Shopping Cart</h1>
        <button
          onClick={() => dispatch(clearCart())}
          className="text-red-500 hover:text-red-700 font-medium"
        >
          Clear Cart
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex items-center p-6 border-b border-gray-100 last:border-0"
          >
            <img
              src={item.image}
              alt={item.title}
              className="w-20 h-20 object-contain"
            />
            <div className="ml-6 flex-1">
              <h3 className="font-bold text-gray-800 line-clamp-1">
                {item.title}
              </h3>
              <p className="text-gray-500">${item.price}</p>
            </div>

            <div className="flex items-center gap-3 bg-gray-50 px-3 py-1 rounded-lg">
              <button
                onClick={() => dispatch(decreaseQuantity(item.id))}
                className="text-xl font-bold"
              >
                -
              </button>
              <span className="font-bold w-6 text-center">{item.quantity}</span>
              <button
                onClick={() => dispatch(addToCart(item))}
                className="text-xl font-bold"
              >
                +
              </button>
            </div>

            <div className="ml-8 text-right min-w-25">
              <p className="font-bold text-lg">
                ${(item.price * item.quantity).toFixed(2)}
              </p>
              <button
                onClick={() => dispatch(removeFromCart(item.id))}
                className="text-xs text-red-400 hover:text-red-600 underline"
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 bg-white p-6 rounded-2xl border border-gray-100 flex justify-between items-center">
        <div>
          <p className="text-gray-500">Total Balance</p>
          <p className="text-3xl font-black text-gray-900">
            ${totalPrice.toFixed(2)}
          </p>
        </div>
        <button className="bg-blue-600 text-white px-10 py-4 rounded-xl font-bold hover:bg-blue-700 transition-colors">
          Checkout
        </button>
      </div>
    </div>
  );
}

export default Cart;
