import { useDispatch, useSelector } from 'react-redux';
import Product from './Product';
import { fetchProducts, setSearchTerm, setMaxPrice } from '../redux/productSlice';
import { useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';

function ProductList() {
  const { products, error, status, searchTerm, maxPrice } = useSelector(state => state.products);
  const { isDarkMode } = useTheme();
  const dispatch = useDispatch();

  useEffect(() => {
    if (products.length === 0) {
      dispatch(fetchProducts());
    }

    return () => {
      dispatch(setSearchTerm(''));
      dispatch(setMaxPrice(''));
    };
  }, [dispatch, products.length]);

  const filteredProducts = products.filter(product => {
    const matchesName = product.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPrice = maxPrice === '' || product.price <= parseFloat(maxPrice);
    return matchesName && matchesPrice;
  });

  if (status === 'loading') {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) return <p className="text-red-500 text-center py-10">Error: {error}</p>;

  return (
    <div>
      <div
        className={`mb-10 p-6 rounded-2xl flex flex-col md:flex-row gap-4 shadow-sm border transition-colors ${
          isDarkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'
        }`}
      >
        <div className="flex-1">
          <label className={`block text-xs font-bold uppercase mb-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
            Search Products
          </label>
          <input
            type="text"
            placeholder="Search by name..."
            className={`w-full p-3 rounded-xl outline-none border-2 focus:border-blue-500 transition-all ${
              isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-100 text-gray-900'
            }`}
            value={searchTerm}
            onChange={e => dispatch(setSearchTerm(e.target.value))}
          />
        </div>

        <div className="md:w-48">
          <label className={`block text-xs font-bold uppercase mb-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
            Max Price ($)
          </label>
          <input
            type="number"
            placeholder="e.g. 100"
            className={`w-full p-3 rounded-xl outline-none border-2 focus:border-blue-500 transition-all ${
              isDarkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-100 text-gray-900'
            }`}
            value={maxPrice}
            onChange={e => dispatch(setMaxPrice(e.target.value))}
          />
        </div>
      </div>

      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProducts.map(product => (
            <Product product={product} key={product.id} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <p className="text-2xl text-gray-400">No products match your search criteria. 🔍</p>
        </div>
      )}
    </div>
  );
}

export default ProductList;
