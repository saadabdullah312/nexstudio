import { Link } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';

function Navbar() {
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <nav
      className={`${isDarkMode ? 'bg-gray-800' : 'bg-blue-600'} text-white shadow-lg sticky top-0 z-50 transition-colors`}
    >
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold tracking-tight">
          E-Store
        </Link>
        <div className="flex items-center space-x-6 font-medium">
          <Link to="/" className="hover:text-blue-200">
            Home
          </Link>
          <Link to="/products" className="hover:text-blue-200">
            Products
          </Link>
          <Link to="/about" className="hover:text-blue-200">
            About
          </Link>
          <Link to="/cart" className="hover:text-blue-200">
            Cart 🛒
          </Link>

          <button
            onClick={toggleTheme}
            className="p-2 rounded-full bg-opacity-20 bg-white hover:bg-opacity-30 transition-all"
          >
            {isDarkMode ? '🌙' : '☀️'}
          </button>
        </div>
      </div>
    </nav>
  );
}
export default Navbar;
