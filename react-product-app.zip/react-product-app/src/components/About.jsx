import { useTheme } from '../context/ThemeContext';

const About = () => {
  const { isDarkMode } = useTheme();

  const developers = [
    { name: 'Fahad', role: 'Lead Developer' },
    { name: 'Nouman', role: 'Frontend Architect' },
    { name: 'Haris', role: 'Backend Specialist' },
    { name: 'Ahsan', role: 'UI/UX Designer' },
  ];

  return (
    <div className="max-w-5xl mx-auto py-12 px-4">
      <section className="text-center mb-20">
        <h2 className="text-5xl font-extrabold mb-6 bg-linear-to-r from-blue-500 to-cyan-500 bg-clip-text text-transparent">
          Our Story
        </h2>
        <p className={`text-xl leading-relaxed max-w-3xl mx-auto ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
          Founded in 2025, E-Store was built to demonstrate the power of modern web technologies. We believe that online
          shopping should be fast, intuitive, and accessible to everyone.
        </p>
      </section>

      <section className="mb-20">
        <h3 className={`text-3xl font-bold text-center mb-12 ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
          Meet the Developers
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {developers.map(dev => (
            <div
              key={dev.name}
              className={`p-6 rounded-2xl text-center transition-transform hover:-translate-y-2 ${
                isDarkMode ? 'bg-gray-800 border border-gray-700' : 'bg-white shadow-lg border border-gray-100'
              }`}
            >
              <div className="w-20 h-20 bg-blue-500 rounded-full mx-auto mb-4 flex items-center justify-center text-white text-2xl font-bold shadow-inner">
                {dev.name[0]}
              </div>
              <h4 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>{dev.name}</h4>
              <p className="text-blue-500 font-medium text-sm uppercase tracking-wide">{dev.role}</p>
            </div>
          ))}
        </div>
      </section>

      <hr className={`mb-20 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-200'}`} />

      <div className="grid md:grid-cols-2 gap-12 mb-16">
        <div className={`p-8 rounded-3xl ${isDarkMode ? 'bg-gray-800' : 'bg-white shadow-xl'}`}>
          <h3 className="text-2xl font-bold mb-4 text-blue-500">Our Mission</h3>
          <p className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
            To provide a seamless interface for exploring high-quality products sourced directly from global APIs, ensuring a
            high-performance experience for users worldwide.
          </p>
        </div>
        <div className={`p-8 rounded-3xl ${isDarkMode ? 'bg-gray-800' : 'bg-white shadow-xl'}`}>
          <h3 className="text-2xl font-bold mb-4 text-cyan-500">The Technology</h3>
          <ul className={`space-y-2 ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            <li>⚡ React 18 & Vite</li>
            <li>🔗 Redux Toolkit for State</li>
            <li>🎨 Tailwind CSS Styling</li>
            <li>🌗 Context API Theme Switching</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default About;
