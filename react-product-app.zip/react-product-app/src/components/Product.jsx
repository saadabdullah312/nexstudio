import { Link } from "react-router-dom";

function Product({ product }) {
  return (
    <Link to={`/products/${product.id}`}>
      <div className="bg-white border border-gray-100 rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col h-full group">
        <div className="h-64 overflow-hidden bg-gray-50 flex items-center justify-center p-6">
          <img
            src={product.image}
            alt={product.title}
            className="max-h-full group-hover:scale-110 transition-transform duration-300"
          />
        </div>
        <div className="p-5 flex flex-col grow">
          <span className="text-xs font-semibold text-blue-500 uppercase tracking-wider mb-2">
            {product.category}
          </span>
          <h1 className="text-gray-800 font-bold text-lg line-clamp-2 mb-3 h-14">
            {product.title}
          </h1>
          <div className="mt-auto flex justify-between items-center">
            <span className="text-2xl font-bold text-gray-900">
              ${product.price}
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}

export default Product;
