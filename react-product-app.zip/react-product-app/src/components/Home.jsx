import { Link } from "react-router-dom";

const Home = () => (
  <div className="flex flex-col items-center justify-center h-[60vh] text-center">
    <h2 className="text-5xl font-extrabold text-blue-900 mb-4">
      Welcome to EStore
    </h2>
    <p className="text-gray-600 text-xl max-w-md">
      The best curated products from the FakeStore API, delivered with a sleek
      React interface.
    </p>
    <Link to="/products" className="text-blue-600 hover:underline">
      View our products
    </Link>
  </div>
);

export default Home;
