import { useDispatch, useSelector } from "react-redux";
import { Link, useParams } from "react-router-dom";
import { addToCart } from "../redux/cartSlice";

function ProductDetail() {
  const dispatch = useDispatch();
  let { id } = useParams();
  id = parseInt(id);

  const product = useSelector((state) =>
    state.products.products.find((el) => el.id === id)
  );

  if (!product) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-gray-600">Product not found</h2>
        <Link to="/products" className="text-blue-600 hover:underline">
          Return to shop
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <Link
        to="/products"
        className="inline-flex items-center text-blue-600 font-medium mb-8 hover:text-blue-800 transition-colors"
      >
        <svg
          className="w-5 h-5 mr-2"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M10 19l-7-7m0 0l7-7m-7 7h18"
          />
        </svg>
        Back to Products
      </Link>

      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
        <div className="flex flex-col md:flex-row">
          <div className="md:w-1/2 bg-gray-50 p-12 flex items-center justify-center">
            <img
              src={product.image}
              alt={product.title}
              className="max-h-100 object-contain hover:scale-105 transition-transform duration-500"
            />
          </div>

          <div className="md:w-1/2 p-8 md:p-12">
            <span className="text-sm font-bold text-blue-600 uppercase tracking-widest px-3 py-1 bg-blue-50 rounded-full">
              {product.category}
            </span>

            <h1 className="text-3xl md:text-4xl font-extrabold text-gray-900 mt-4 mb-6 leading-tight">
              {product.title}
            </h1>

            <div className="flex items-center mb-6">
              <div className="flex items-center bg-yellow-100 text-yellow-800 px-3 py-1 rounded-lg font-bold">
                {product.rating?.rate} <span className="ml-1 text-lg">⭐</span>
              </div>
              <span className="ml-4 text-gray-500 font-medium">
                ({product.rating?.count} reviews)
              </span>
            </div>

            <p className="text-gray-600 text-lg leading-relaxed mb-8">
              {product.description}
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-6 mt-auto border-t border-gray-100 pt-8">
              <span className="text-4xl font-black text-gray-900">
                ${product.price}
              </span>
              <button
                className="w-full sm:w-auto flex-1 bg-blue-600 hover:bg-blue-700 text-white text-lg font-bold py-4 px-8 rounded-2xl shadow-lg shadow-blue-200 transition-all active:scale-95 flex items-center justify-center gap-2"
                onClick={() => dispatch(addToCart(product))}
              >
                <span>Add to cart</span>
                <span className="text-xl">🛒</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;
