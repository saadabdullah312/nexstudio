import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';
import { api } from '../api/api';

export const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
  const response = await axios.get(api);
  return response.data;
});

const initialState = {
  status: 'loading',
  error: null,
  products: [],
  searchTerm: '',
  maxPrice: '',
};

const productSlice = createSlice({
  name: 'products',
  initialState,
  reducers: {
    setSearchTerm: (state, action) => {
      state.searchTerm = action.payload;
    },
    setMaxPrice: (state, action) => {
      state.maxPrice = action.payload;
    },
  },
  extraReducers: builder => {
    builder
      .addCase(fetchProducts.pending, state => {
        state.status = 'loading';
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.status = 'fulfilled';
        state.products = action.payload;
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.status = 'rejected';
        state.error = action.error.message;
      });
  },
});

export const { setSearchTerm, setMaxPrice } = productSlice.actions;
export default productSlice.reducer;
