const limit = 20;
export const api = `https://fakestoreapi.com/products?limit=${limit}`;
