function HomeSlider() {
  return (
    <div className="max-w-7xl m-auto flex items-center justify-center mt-[10vh] gap-5">
      <img src="https://nexstudio.demos.tailgrids.com/images/clients/logo-1.svg" alt="Logo 1" />
      <img src="https://nexstudio.demos.tailgrids.com/images/clients/logo-2.svg" alt="Logo 2" />

      <img src="https://nexstudio.demos.tailgrids.com/images/clients/logo-1.svg" alt="Logo 3" />
      <img src="https://nexstudio.demos.tailgrids.com/images/clients/logo-2.svg" alt="Logo 4" />
    </div>
  );
}

export default HomeSlider;
