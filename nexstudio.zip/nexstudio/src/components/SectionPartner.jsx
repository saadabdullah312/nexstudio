import PartnerCard from './PartnerCard';

function SectionPartner() {
  return (
    <div className="max-w-6xl m-auto mt-16 flex flex-col gap-10">
      <h1 className="text-4xl">Why Partner With Us</h1>

      <div className="flex gap-5">
        <PartnerCard
          cardHeading="Custom Solutions"
          cardDesc="Tailored software crafted to meet your unique business challenges and goals."
        />
        <PartnerCard
          cardHeading="Dedicated Support"
          cardDesc="Reliable assistance and maintenance to ensure your systems run smoothly."
        />
        <PartnerCard
          cardHeading="Innovative Tech"
          cardDesc="Cutting-edge technologies to drive efficiency and competitive advantage."
        />
        <PartnerCard
          cardHeading="Expert Team"
          cardDesc="Seasoned professionals committed to delivering excellence in every project."
        />
      </div>
    </div>
  );
}

export default SectionPartner;
