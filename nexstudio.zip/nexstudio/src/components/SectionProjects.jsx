import Button from '../common/Button';

function Project() {
  return (
    <div className="bg-[#0a0a0a] text-white border border-[#1f1f1f] rounded-2xl overflow-hidden p-7 flex flex-col gap-4">
      <h2 className="text-[18px]">Finance Management System</h2>
      <div className="flex justify-between items-center">
        <h2 className="uppercase font-light">web app</h2>
        <h2 className="uppercase font-light">Mar 2022</h2>
      </div>

      <div className="h-[40vh]">
        <img
          className="object-cover h-full w-full rounded-2xl"
          src="https://nexstudio.demos.tailgrids.com/images/project/project-1.jpg"
          alt=""
        />
      </div>
    </div>
  );
}

function SectionProjects() {
  return (
    <div className="max-w-full mt-8 bg-black rounded-2xl py-10">
      <div className="max-w-6xl m-auto py-[5vh] flex flex-col gap-9 items-start">
        <h1 className="text-4xl text-white mb-9">
          NexStudio <i>Projects</i>
        </h1>

        <div className="flex items-center gap-8">
          <Project />
          <Project />
        </div>

        <button className="bg-white text-black rounded-full px-6 py-4 cursor-pointer uppercase">Explore all projects</button>
      </div>
    </div>
  );
}

export default SectionProjects;
