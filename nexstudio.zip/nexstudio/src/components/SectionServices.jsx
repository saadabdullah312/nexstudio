function Service({ no, heading, desc }) {
  return (
    <div className="w-full flex justify-between items-center">
      <span>{no}</span>
      <h1 className="text-2xl">{heading}</h1>
      <p className="text-gray-600 w-[30%]">{desc}</p>
    </div>
  );
}

function SectionServices() {
  return (
    <div className="max-w-6xl m-auto mt-[15vh] flex flex-col gap-6">
      <h1 className="text-4xl">Our Services</h1>

      <div className="pl-10 mt-16 flex flex-col gap-20">
        <Service
          no="#1"
          heading="Web App Development"
          desc="Build blazing-fast web applications with clean architecture and scalable infrastructure."
        />
        <Service
          no="#2"
          heading="Mobile App Development"
          desc="Build blazing-fast web applications with clean architecture and scalable infrastructure."
        />

        <Service
          no="#3"
          heading="API & Backend Solutions"
          desc="Build blazing-fast web applications with clean architecture and scalable infrastructure."
        />

        <Service
          no="#4"
          heading="Maintenance & Growth"
          desc="Build blazing-fast web applications with clean architecture and scalable infrastructure."
        />
      </div>
    </div>
  );
}

export default SectionServices;
