import Button from '../common/Button';

function Home() {
  return (
    <div className="max-w-3xl m-auto flex items-center justify-between flex-col mt-[14vh] text-center gap-4">
      <h1 className="text-5xl">
        We Build <i> Digital Products</i> That Drive Growth.
      </h1>

      <p className="text-gray-600">
        From startups to global brands — we design, develop, and deliver high-performing web and mobile solutions that turn
        ideas into impact.
      </p>

      <div className="flex gap-3 items-center">
        <Button btnText="Explore projects" dark={true} />
        <Button btnText="Contact us" dark={false} border={true} />
      </div>
    </div>
  );
}

export default Home;
