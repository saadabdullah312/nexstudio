import Button from '../common/Button';

function NavBar() {
  return (
    <nav className="max-w-7xl m-auto flex items-center justify-between">
      <img src="https://nexstudio.demos.tailgrids.com/images/layout/logo-black.svg" alt="nexStudio logo" />

      <ul className="flex items-center gap-5">
        <li className="uppercase">Projects</li>
        <li className="uppercase">Services</li>
        <li className="uppercase">About</li>
        <li className="uppercase">Blog</li>
      </ul>

      <Button btnText="get started" dark={true} />
    </nav>
  );
}

export default NavBar;
