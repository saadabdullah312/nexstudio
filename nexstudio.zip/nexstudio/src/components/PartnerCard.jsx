function PartnerCard({ cardHeading, cardDesc }) {
  return (
    <div className="flex flex-col gap-5">
      <span>ICON</span>
      <h2 className="text-2xl">{cardHeading}</h2>
      <p className="text-gray-600">{cardDesc}</p>
    </div>
  );
}

export default PartnerCard;
