function SectionBuilder() {
  return (
    <div className="py-10 bg-black text-white mt-6">
      <div className="max-w-6xl m-auto flex items-center justify-between">
        <div className="w-[40%]">
          <h1 className="text-4xl">
            A Team of Builders &<i>Innovators</i>
          </h1>
        </div>

        <div className="w-[50%] flex flex-col gap-5">
          <p>we combine creativity with engineering discipline to build products that users love.</p>
          <p>
            From early-stage startups to established enterprises, we help our clients transform complex problems into simple,
            elegant solutions.
          </p>

          <div className="flex gap-10 w-[70%] justify-between">
            <div>
              <h1 className="text-5xl">5K+</h1>
              <p>Projects Delivered</p>
            </div>

            <div>
              <h1 className="text-5xl">$1M+</h1>
              <p>Revenue Generated</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SectionBuilder;
