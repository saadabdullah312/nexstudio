function HomeHeroImage() {
  return (
    <div className="max-w-7xl m-auto mt-[10vh]">
      <img
        className="rounded-2xl"
        src="https://nexstudio.demos.tailgrids.com/images/cover/clients-cover.jpg"
        alt="nexStudio home"
      />
    </div>
  );
}

export default HomeHeroImage;
