function SectionIdea() {
  return (
    <div className="bg-[#fbfbfb] py-10">
      <div className="max-w-6xl m-auto flex items-center justify-between">
        <h1 className="text-4xl w-[40%]">Ready to build your nextbig idea?</h1>

        <button className="text-black bg-white border border-black px-6 py-3 rounded-4xl cursor-pointer">Contact Us</button>
      </div>
    </div>
  );
}

export default SectionIdea;
