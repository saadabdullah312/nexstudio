function Blog() {
  return (
    <div className="flex flex-col gap-3">
      <img
        className="rounded-2xl cursor-pointer"
        src="https://nexstudio.demos.tailgrids.com/images/blog/thumb-2.jpg"
        alt=""
      />
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between font-light">
          <p>APP DESIGN</p>
          <p>AUG 2026</p>
        </div>

        <p className="text-[20px] font-light">The Future of Web UX: Trends That Will Shape 2025</p>
      </div>
    </div>
  );
}

function SectionBlogs() {
  return (
    <div className="max-w-full mt-8 py-10">
      <div className="max-w-6xl m-auto py-[5vh] flex flex-col gap-9 items-start">
        <h1 className="w-max text-[45px]">
          NexStudio<i>Blogs</i>
        </h1>

        <div className="flex items-center gap-8">
          <Blog />
          <Blog />
        </div>
      </div>
    </div>
  );
}

export default SectionBlogs;
