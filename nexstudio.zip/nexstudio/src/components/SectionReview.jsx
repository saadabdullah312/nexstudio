function Review() {
  return (
    <div className="bg-[#fbfbfb] border border-[#d1d5dc] rounded-2xl flex flex-col items-start p-12">
      <img className="h-10 opacity-25 mb-3" src="https://nexstudio.demos.tailgrids.com/images/clients/logo-1.svg" alt="" />

      <p className="mb-3">
        DigitX transformed our outdated website into a modern, responsive platform. Their attention to detail and ability to
        understand our vision made the entire process smooth and hassle-free.
      </p>

      <h2 className="text-black font-semibold text-2xl">Michael Johnson</h2>
      <p className="text-gray-400">Marketing manager at globaltech solutions.</p>
    </div>
  );
}

function SectionReview() {
  return (
    <div className="max-w-6xl m-auto py-10 flex gap-10 items-center">
      <div className="flex flex-col gap-5">
        <h1 className="w-max text-[45px]">
          Our Client<i>Reviews</i>
        </h1>

        <div className="flex gap-3">
          <button className="border border-black rounded-[100px] py-1 px-2 cursor-pointer">
            <i class="fa-solid fa-angle-left"></i>
          </button>
          <button className="border border-black rounded-[100px] py-1 px-2 cursor-pointer">
            <i class="fa-solid fa-angle-right"></i>
          </button>
        </div>
      </div>

      <div className="flex gap-10">
        <Review />
        <Review />
      </div>
    </div>
  );
}

export default SectionReview;
