import Footer from './components/Footer';
import Home from './components/Home';
import HomeHeroImage from './components/HomeHeroImage';
import HomeSlider from './components/HomeSlider';
import NavBar from './components/NavBar';
import SectionBlogs from './components/SectionBlogs';
import SectionBuilder from './components/SectionBuilder';
import SectionIdea from './components/SectionIdea';
import SectionPartner from './components/SectionPartner';
import SectionProjects from './components/SectionProjects';
import SectionReview from './components/SectionReview';
import SectionServices from './components/SectionServices';

function App() {
  return (
    <div className="pt-8">
      <NavBar />

      <Home />
      <HomeSlider />
      <HomeHeroImage />
      <SectionBuilder />
      <SectionPartner />
      <SectionServices />
      <SectionProjects />
      <SectionReview />
      <SectionBlogs />
      <SectionIdea />
      <Footer />
    </div>
  );
}

export default App;
