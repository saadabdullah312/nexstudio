function Button({ btnText, dark, border }) {
  return (
    <button
      className={`text-${dark ? 'white' : 'black'} bg-${dark ? 'black' : 'white'} rounded-4xl px-4 py-3 uppercase text-[15px] cursor-pointer ${border && 'border border-black'}`}
    >
      {btnText}
    </button>
  );
}

export default Button;
